#!/bin/bash

rm mirage335-BaseEbuilds.tar.gz
tar -cvf mirage335-BaseEbuilds.tar.gz *